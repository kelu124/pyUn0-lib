class Configuration(object):
    ENV='development'
    DEBUG=True
    HOST='0.0.0.0'
    LIB_PATH='/home/pi/pyUn0-lib/'
