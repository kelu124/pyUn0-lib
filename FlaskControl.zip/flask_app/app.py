from flask import Flask
from config import Configuration
from flask import render_template
from flask import request
import sys
import json

sys.path.append(Configuration.LIB_PATH)
from spi_connector import SpiConnector
from pyUn0 import DataToJson
from pyUn0 import make_clean
import os
app=Flask(__name__, static_url_path='/static')
app.config.from_object(Configuration)



@app.route('/',methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/',methods=['POST'])
def activ():
    #UN0RICK = SpiConnector()
    #UN0RICK.test_spi(3)
    button_type=request.form.get('button1')
    
    if button_type=='test':
        UN0RICK = SpiConnector()
        UN0RICK.test_spi(3)
    elif button_type=='acquisition':
        UN0RICK = SpiConnector()
        UN0RICK.test_spi(3)

        UN0RICK.set_HV(1000)
        UN0RICK.set_hilo(1)
        TGCC = UN0RICK.create_tgc_curve(600, 900, True)[0]  # Gain: linear, 10mV to 980mV
        UN0RICK.set_tgc_curve(TGCC)  # We then apply the curve
        UN0RICK.set_tgc_constant(600)  # Sets in mV from 0 to 1000
        UN0RICK.set_period_between_acqs(int(2500000))  # Setting 2.5ms between shots
        UN0RICK.JSON["N"] = 1  # Experiment ID of the day
        UN0RICK.set_multi_lines(False)  # Single acquisition
        UN0RICK.set_acquisition_number_lines(1)  # Setting the number of lines (1)
        UN0RICK.set_msps(0)  # Sampling speed setting
        A = UN0RICK.set_timings(
            200, 10, 200, 2000, 5000, 190000
        )  # Settings the series of pulses
        UN0RICK.JSON[
            "data"
        ] = UN0RICK.do_acquisition()  # Doing the acquisition and saves
        UN0RICK.set_led_rgb(0, 0, 0)
        
        make_clean("./")
        MyDataFile=UN0RICK.JSON["experiment"]["id"] + "-" + str(UN0RICK.JSON["N"]) + ".json"
        if not MyDataFile in os.listdir("./data/"):
            MyDataFile='test.json'
        if MyDataFile in os.listdir("./data/"):
            print(MyDataFile)
            y = DataToJson()
            y.show_images = False
            y.json_proccess("./data/" + MyDataFile)
            #y.create_fft()
            #y.save_npz()
            #y.make_image()
            title_text=y.create_title_text()
            x1=y.t[0 : y.len_line]
            y2=y.tdac[0 : y.len_line]
            y1=y.tmp[0 : y.len_line]
            return render_template('index.html',title_text=title_text,x1=x1,y1=y1,y2=y2)
        
    return render_template('index.html')
            

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'),404


if __name__=='__main__':
    app.run(Configuration.HOST)
